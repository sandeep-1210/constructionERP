
export class config {
    public static apiUrl = 'http://localhost:3000/api';
}